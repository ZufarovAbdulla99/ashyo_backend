export declare interface UpdateBrandRequest {
    id: number
    name?: string,
    image?: string
}