export declare interface CreateBrandRequest {
    name: string,
    image: string
}