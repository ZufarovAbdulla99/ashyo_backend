import {
  forwardRef,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateLikeDto, ToggleLikeDto, UpdateLikeDto } from './dtos';
// import { Product, ProductService } from '../product';
import { Product } from '../product/models/product.model';
// import { ProductService } from '../product/product.service';
import {ProductService} from 'src/modules/product/product.service'
import { Like } from './models';

@Injectable()
export class LikeService {
  constructor(
    @InjectRepository(Like)
    private readonly likeRepository: Repository<Like>,

    @Inject(forwardRef(() => ProductService))
    private readonly productService: ProductService,
  ) {}

  async toggleLike(
    toggleLikeDto: ToggleLikeDto,
  ): Promise<{ message: string; isLiked: boolean }> {
    const { userId, productId } = toggleLikeDto;

    const existing = await this.likeRepository.findOne({
      where: { user_id: userId, product_id: productId },
    });

    let created = false;

    if (!existing) {
      const newLike = this.likeRepository.create({
        user_id: userId,
        product_id: productId,
      });
      await this.likeRepository.save(newLike);
      created = true;
    } else {
      await this.likeRepository.remove(existing);
    }

    const product = await this.productService.getSingleProduct(productId);
    if (!product) {
      throw new NotFoundException(`Product with ID ${productId} not found`);
    }

    // product.is_liked front uchun vaqtinchalik qiymat, bazaga yozilmaydi
    return {
      message: created
        ? 'Product liked successfully'
        : 'Product unliked successfully',
      isLiked: created,
    };
  }

  async getLikedProducts(userId: number): Promise<Product[]> {
    return this.productService.findLikedByUser(userId);
  }

  async getLikedProductsIdsArray(userId: number): Promise<number[]> {
    const likedProducts = await this.productService.findLikedByUser(userId);
    return likedProducts.map((product) => product.id);
  }

  async getSingleLike(id: number): Promise<Like> {
    const like = await this.likeRepository.findOne({ where: { id } });
    if (!like) throw new NotFoundException(`Like with ID ${id} not found`);
    return like;
  }

  async createLike(
    payload: CreateLikeDto,
  ): Promise<{ message: string; new_like: Like }> {
    const newLike = this.likeRepository.create(payload);
    await this.likeRepository.save(newLike);
    return {
      message: 'Like created successfully!',
      new_like: newLike,
    };
  }

  async updateLike(
    id: number,
    payload: UpdateLikeDto,
  ): Promise<{ message: string; updatedLike: Like }> {
    await this.likeRepository.update(id, payload);
    const updatedLike = await this.likeRepository.findOne({ where: { id } });
    if (!updatedLike)
      throw new NotFoundException(`Like with ID ${id} not found`);
    return {
      message: 'Like updated successfully',
      updatedLike,
    };
  }

  async deleteLike(id: number): Promise<{ message: string }> {
    const like = await this.likeRepository.findOne({ where: { id } });
    if (!like) {
      return { message: `${id} raqamli Like topilmadi!!!` };
    }
    await this.likeRepository.remove(like);
    return {
      message: 'Like deleted successfully',
    };
  }
}