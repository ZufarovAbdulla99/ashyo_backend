export * from './create-like.interface'
export * from './update-like.interface'