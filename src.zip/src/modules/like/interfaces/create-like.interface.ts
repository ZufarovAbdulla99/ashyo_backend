export declare interface CreateLikeRequest {
    user_id:number;
    product_id:number;
}