export declare interface UpdateLikeRequest {
    user_id?:number;
    product_id?:number;
}