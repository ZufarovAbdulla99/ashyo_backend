import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LikeService } from './like.service';
import { LikeController } from './like.controller';
import { ProductModule } from '../product';
import { Like } from './models';

@Module({
  imports: [TypeOrmModule.forFeature([Like]), forwardRef(() => ProductModule), ProductModule],
  controllers: [LikeController],
  providers: [LikeService],
  exports: [LikeService],
})
export class LikeModule {}
