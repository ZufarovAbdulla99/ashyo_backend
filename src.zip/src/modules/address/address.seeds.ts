export const addressSeedData = [
  {
    user_id: 1,
    region_id: 2,
    city_id: null,
    district_id: 3,
    street: 'Amir Temur street, 15',
  },
  {
    user_id: 1,
    region_id: 2,
    city_id: null,
    district_id: 4,
    street: 'Shahrisabz street, 19',
  },
  {
    user_id: 1,
    region_id: 4,
    city_id: null,
    district_id: 3,
    street: 'Beruniy street, 5',
  },
];
