import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderItemsService } from './order_items.service';
import { OrderItemsController } from './order_items.controller';
import { OrderItems } from './models';
import { ProductItem } from '../product_item';
import { Order } from '../order/models';

@Module({
  imports: [TypeOrmModule.forFeature([OrderItems, ProductItem, Order])],
  controllers: [OrderItemsController],
  providers: [OrderItemsService],
})
export class OrderItemsModule {}

