export declare interface UpdateCommentRequest {
    text:string;
    user_id?: number;
    product_id?: number;
}