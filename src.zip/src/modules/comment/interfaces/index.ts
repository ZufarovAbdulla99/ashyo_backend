export * from './create-comment.interface'
export * from './update-comment.interface'