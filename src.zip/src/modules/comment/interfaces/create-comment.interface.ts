export declare interface CreateCommentRequest {
    text:string;
    user_id: number;
    product_id: number;
}