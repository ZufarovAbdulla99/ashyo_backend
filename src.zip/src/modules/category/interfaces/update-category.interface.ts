export declare interface UpdateCategoryRequest {
  id: number;
  name?: string;
  image?: string;
  icon?: string;
}
