export declare interface CreateCategoryRequest {
  name: string;
  parentCategoryId?: number;
  image: string;
  icon: string;
}
