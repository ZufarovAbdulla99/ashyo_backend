export interface VariationOptionAttributes {
    id?: number;
    variation_id: number;
    value: string;
}
