export enum UserRoles {
    user = 'USER',
    admin = 'ADMIN',
}