import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderService } from './order.service';
import { OrderController } from './order.controller';
import { Order } from './models';
import { User } from '../user';
import { Address } from '../address';

@Module({
  imports: [TypeOrmModule.forFeature([Order, User, Address])],
  controllers: [OrderController],
  providers: [OrderService],
})
export class OrderModule {}
