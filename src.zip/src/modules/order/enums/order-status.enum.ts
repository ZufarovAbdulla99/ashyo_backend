export enum OrderStatus {
  processing = 'processing',
  delivered = 'delivered',
  denied = 'denied',
}