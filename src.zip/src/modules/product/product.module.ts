import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Product } from './models/product.model';
import { ProductService } from './product.service';
import { FileService } from '../file/file.service';
import { ProductController } from './product.controller';
import { LikeModule } from '../like/like.module';
import { Category } from '../category/models/category.model';
import { ProductItem } from '../product_item/models/product_item.entity';
import { ProductConfiguration } from '../product_configuration/models/product_configuration.model';
import { VariationOption } from '../variation_option/models/variation_option.model';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Product,
      Category,
      ProductItem,
      ProductConfiguration,
      VariationOption,
    ]),
    forwardRef(() => LikeModule),
    LikeModule,
  ],
  controllers: [ProductController],
  providers: [ProductService, FileService],
  exports: [ProductService],
})
export class ProductModule {}

