export declare interface CreateCartRequest {
    user_id: number;
    product_id: number;
}