export declare interface UpdateCartRequest {
    user_id?: number;
    product_id?: number;
}